﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp
{
    internal  class repository
    {
        public void Save(string msg)
        {
            try
            {
                File.AppendAllText("transaction.txt", msg);
            }
            catch
            {
                UnableToSaveDataException u = new UnableToSaveDataException("transaction not saved");
                throw u;
            }
        }
    }
}
