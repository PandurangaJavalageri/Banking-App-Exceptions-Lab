﻿using System;

namespace BankingApp
{
    public class UnableToSaveDataException:ApplicationException
    {
        public UnableToSaveDataException(string msg = null, Exception ex = null) : base(msg, ex)
        {

        }
    }
}
