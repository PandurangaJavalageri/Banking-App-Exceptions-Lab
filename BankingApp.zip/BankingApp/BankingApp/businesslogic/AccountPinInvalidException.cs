﻿using System;

namespace BankingApp
{
    public class AccountPinInvalidException:ApplicationException
    {
        public AccountPinInvalidException(string msg):base(msg)
        {
            
        }
    }


}
