﻿using System;

namespace BankingApp
{
    public class AccountInactiveException:ApplicationException
    {
        public AccountInactiveException(string msg):base(msg) 
        { 

        }
        
    }


}
