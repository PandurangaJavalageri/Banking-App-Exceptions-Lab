﻿using System;

namespace BankingApp
{
    public class AmountWithdrawalException : ApplicationException
    {
        public AmountWithdrawalException(string msg):base (msg)
        {
            
        }
    }


}
