﻿using System;

namespace BankingApp
{
    public class InvalidAccountNumberException:ApplicationException
    {
        public InvalidAccountNumberException(string msg):base(msg)
        {
            
        }
    }


}
