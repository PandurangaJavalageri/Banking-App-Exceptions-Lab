﻿using System;

namespace BankingApp
{
    public class Bank
    {
        public int AccNo { get; set; }
        public int CurrentBalance { get; set; }
        public bool isActive { get; set; }
        public int MinimumBalance { get; set; }
        public int Pin { get; set; }
        public string Deposit(int amount, int AccNo)
        {
            // valid accNo 
            // valid amount (amount > 0)
            // should be active acc
            
                if (this.AccNo != AccNo)
                {
                    throw new InvalidAccountNumberException("Account not found");
                }
                if (!isActive)
                {
                    throw new AccountInactiveException("Account is not in active state");
                }
                if (amount < 0)
                {
                    throw new AmountInvalidException("Amount is less than the zero");
                }
                


            
            
            this.CurrentBalance = amount + CurrentBalance;
            repository r = new repository();
            r.Save($"my new balance is {this.CurrentBalance}");
            return $"my new balance is { this.CurrentBalance }";
        }
        public string WithDraw(int amount, int AccNo, int Pin)
        {
            // valid accno
            // valid amount (> 0)
            // sufficcient balance
            // must maintain min balance 5000-1000 <= 1000
            // must be active account
            // valid pin
            
            
                if (this.AccNo != AccNo)
                {
                    throw new InvalidAccountNumberException("Account not found");
                }
                
                if (!isActive)
                {
                    throw new AccountInactiveException("Account is not in active state");
                }
                if (this.Pin != Pin)
                {
                    throw new AccountPinInvalidException("Account pin is incorrect");
                }
                if (amount < 0)
                {
                    throw new AmountInvalidException("Amount is less than the zero");
                }
                if (CurrentBalance <= MinimumBalance)
                {
                    throw new MinimumBalanceException("Account does not contain balance equal to sufficient balance");
                }
                if (CurrentBalance < amount)
                {
                    throw new AmountWithdrawalException("Amount withdrawing is greater than the current bal in ur account");
                }
                else
                {
                    this.CurrentBalance = CurrentBalance - amount;
                    repository r = new repository();
                    r.Save($"my new balance is {this.CurrentBalance}");
                    return $"my new balance is {this.CurrentBalance}";
            }
            
            

            
            

        }
        public string Transfer(int amount, int AccNo, int Pin, int ToAccNo)
        {
            // all deposit business rules
            // all withdrawal business rules
            // else throw exp
           
                if (this.AccNo != AccNo)
                {
                    throw new InvalidAccountNumberException("Account not found");
                }
                if (!isActive)
                {
                    throw new AccountInactiveException("Account is not in active state");
                }
                if (amount < 0)
                {
                    throw new AmountInvalidException("Amount is less than the zero");
                }
                
                if (this.Pin != Pin)
                {
                    throw new AccountPinInvalidException("Account pin is incorrect");
                }
                if (CurrentBalance <= MinimumBalance)
                {
                    throw new MinimumBalanceException("Account does not contain balance equal to sufficient balance");
                }
                if (CurrentBalance < amount)
                {
                    throw new AmountWithdrawalException("Amount withdrawing is greater than the current bal in ur account");
                }
                else
                {
                    this.CurrentBalance = CurrentBalance - amount;
                    repository r = new repository();
                    r.Save($"my new balance is {this.CurrentBalance}");
                return $"my new balance is {this.CurrentBalance}";
            }
           
            
            
            
        }
    }


}
