﻿using System;

namespace BankingApp
{
    public class MinimumBalanceException:ApplicationException
    {
        public MinimumBalanceException(string msg):base(msg)
        {
            
        }
    }


}
