﻿using System;

namespace BankingApp
{
    public class AmountInvalidException : ApplicationException
    {
        public AmountInvalidException(string msg):base(msg)
        {
            
        }
    }


}
