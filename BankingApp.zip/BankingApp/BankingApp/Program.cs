﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
                Console.WriteLine("enter the customer details");
                Bank bank = new Bank();
                Console.WriteLine("enter Account No");
                bank.AccNo = int.Parse(Console.ReadLine());
                Console.WriteLine("enter Current Balance");
                bank.CurrentBalance = int.Parse(Console.ReadLine());
                Console.WriteLine("enter Minimum Balance");
                bank.MinimumBalance = int.Parse(Console.ReadLine());
                Console.WriteLine("enter account pin");
                bank.Pin = int.Parse(Console.ReadLine());
                bank.isActive = bool.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine(bank.Deposit(5000, 123234345));
                Console.WriteLine(bank.WithDraw(10000, 123234345, 45623));
                Console.WriteLine(bank.Transfer(10000, 123234345, 45623, 232232));
            }
            catch (InvalidAccountNumberException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (AmountInvalidException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (AccountInactiveException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (AccountPinInvalidException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (MinimumBalanceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (AmountWithdrawalException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }





        }
    }
}
